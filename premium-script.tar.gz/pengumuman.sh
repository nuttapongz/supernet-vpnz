#!/bin/bash
# Created by Tae.TaRuMa
curl Tae.TaRuMa/index.html
echo ""